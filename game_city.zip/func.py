import random

def parameters(toponym_longitude, toponym_lattitude):
    delta = '0.04'
    spis = ['map', 'sat',]
    tip = random.choice(spis)
    map_params = {
        "ll": ",".join([toponym_longitude, toponym_lattitude]),
        "spn": ",".join([delta, delta]),
        "l": tip
    }
    return map_params
